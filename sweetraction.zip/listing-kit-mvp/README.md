# Instant Marketplace Listing Kit

A small, launchable MVP for a paid AI listing generator.

## What it does
- Landing page
- Listing generator page
- 3 free generations per browser
- Stripe Checkout unlock for unlimited use on that browser
- OpenAI-powered listing generation
- Ready for Vercel deployment

## Local setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy env vars:
   ```bash
   cp .env.example .env.local
   ```
3. Fill in:
   - `OPENAI_API_KEY`
   - `STRIPE_SECRET_KEY`
   - `STRIPE_PRICE_ID`
   - `PRODUCT_UNLOCK_SECRET`
   - `APP_URL`
4. Run locally:
   ```bash
   npm run dev
   ```

## Stripe setup
Create a product in Stripe for your paid unlock, then copy its Price ID into `STRIPE_PRICE_ID`.

Suggested starting offer:
- Product name: `Unlimited Listing Generator`
- Type: one-time payment
- Price: `$19`

## Deploy to Vercel
1. Push the repo to GitHub.
2. Import it into Vercel.
3. Add the same environment variables in Vercel Project Settings.
4. Redeploy after adding env vars.
5. Set `APP_URL` to your production domain.

## Important MVP caveats
- The paid unlock is stored in a signed browser cookie after Stripe confirms checkout.
- That means the unlock is device/browser specific.
- For a real SaaS version, add auth, a database, webhooks, and user accounts.

## Fast next upgrades
- Add image upload + vision input
- Save listing history
- Add copy buttons
- Support subscriptions instead of one-time unlock
- Add auth with Clerk/Supabase/Auth.js
- Add Stripe webhook syncing
