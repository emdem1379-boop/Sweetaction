import OpenAI from 'openai';
import { getOpenAIModel, requiredEnv } from '@/lib/env';

let client: OpenAI | null = null;

function getClient() {
  if (!client) {
    client = new OpenAI({ apiKey: requiredEnv('OPENAI_API_KEY') });
  }
  return client;
}

export type ListingResult = {
  title: string;
  priceSuggestion: string;
  description: string;
  tags: string[];
  category: string;
  sellingTips: string[];
};

export async function generateListing(input: {
  itemName: string;
  platform: string;
  condition: string;
  notes: string;
}) {
  const prompt = `You write high-converting secondhand marketplace listings.
Return ONLY valid JSON with this exact shape:
{
  "title": string,
  "priceSuggestion": string,
  "description": string,
  "tags": string[],
  "category": string,
  "sellingTips": string[]
}

Rules:
- Keep the title under 80 characters.
- The description should be 60 to 120 words.
- Make the copy natural, specific, and easy to paste into ${input.platform}.
- priceSuggestion must be a short range like "$20-$30" or "$120 firm".
- tags should contain 5 to 8 short tags.
- sellingTips should contain 3 short practical tips.
- Do not mention missing information as unknown. Use cautious, general wording when details are sparse.

Item name: ${input.itemName}
Condition: ${input.condition}
Platform: ${input.platform}
Seller notes: ${input.notes}`;

  const response = await getClient().responses.create({
    model: getOpenAIModel(),
    input: prompt,
  });

  const text = response.output_text;
  const parsed = JSON.parse(text) as ListingResult;

  return {
    ...parsed,
    tags: Array.isArray(parsed.tags) ? parsed.tags.slice(0, 8) : [],
    sellingTips: Array.isArray(parsed.sellingTips) ? parsed.sellingTips.slice(0, 3) : [],
  };
}
