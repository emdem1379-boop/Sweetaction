import { cookies } from 'next/headers';

const COOKIE_NAME = 'listingkit_free_uses';
const FREE_LIMIT = 3;

export async function getRemainingFreeUses() {
  const cookieStore = await cookies();
  const used = Number(cookieStore.get(COOKIE_NAME)?.value || '0');
  const safeUsed = Number.isFinite(used) && used >= 0 ? used : 0;
  return Math.max(0, FREE_LIMIT - safeUsed);
}

export async function consumeFreeUse() {
  const cookieStore = await cookies();
  const used = Number(cookieStore.get(COOKIE_NAME)?.value || '0');
  const nextUsed = Number.isFinite(used) && used >= 0 ? used + 1 : 1;
  cookieStore.set(COOKIE_NAME, String(nextUsed), {
    httpOnly: true,
    sameSite: 'lax',
    secure: true,
    path: '/',
    maxAge: 60 * 60 * 24 * 30,
  });
}

export { FREE_LIMIT };
